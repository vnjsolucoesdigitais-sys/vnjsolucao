const PNCP='https://pncp.gov.br/api/consulta/v1';

export default {
  async scheduled(controller, env, ctx) {
    ctx.waitUntil(runSync(env));
  }
};

async function runSync(env){
  const now=new Date();
  try{
    const to=now.toISOString().slice(0,10).replaceAll('-','');
    let saved=0;
    for(let page=1;page<=5;page++){
      const url=new URL(`${PNCP}/contratacoes/proposta`);
      url.searchParams.set('dataFinal',to);url.searchParams.set('pagina',String(page));url.searchParams.set('tamanhoPagina','50');
      const response=await fetch(url,{headers:{accept:'application/json','User-Agent':'VNJ-Painel-Licitacoes/1.0'}});
      if(!response.ok)throw new Error(`PNCP ${response.status}`);
      const payload=await response.json();const rows=Array.isArray(payload)?payload:(payload.data||payload.content||payload.items||payload.results||[]);
      if(!rows.length)break;
      for(const x of rows){
        const org=x.orgaoEntidade||{},unit=x.unidadeOrgao||{};
        const cnpj=String(x.cnpj||org.cnpj||'');
        const id=String(x.numeroControlePNCP||x.numeroControlePncp||`${cnpj}-${x.anoCompra||''}-${x.sequencialCompra||''}`);
        if(!id.replaceAll('-',''))continue;
        const existing=await env.DB.prepare('SELECT id FROM tenders WHERE pncp_id=?').bind(id).first();
        const localId=existing?.id||crypto.randomUUID();
        const title=String(x.objetoCompra||x.informacaoComplementar||'');
        await env.DB.prepare(`INSERT INTO tenders(id,source,pncp_id,pncp_url,number,buyer_name,buyer_cnpj,title,object,category,state,city,published_at,opening_at,proposal_deadline,estimated_value,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(pncp_id) DO UPDATE SET pncp_url=excluded.pncp_url,buyer_name=excluded.buyer_name,title=excluded.title,object=excluded.object,category=excluded.category,state=excluded.state,city=excluded.city,opening_at=excluded.opening_at,proposal_deadline=excluded.proposal_deadline,estimated_value=excluded.estimated_value,updated_at=CURRENT_TIMESTAMP`).bind(localId,'pncp',id,x.linkSistemaOrigem||`https://pncp.gov.br/app/editais/${cnpj}/${x.anoCompra||now.getFullYear()}/${x.sequencialCompra||''}`,String(x.numeroCompra||x.numeroAviso||x.numeroProcesso||''),String(org.razaoSocial||x.orgaoNome||''),cnpj,title,title,String(x.modalidadeNome||''),String(unit.ufSigla||unit.ufNome||x.uf||''),String(unit.municipioNome||x.municipioNome||''),x.dataPublicacaoPncp||x.dataPublicacao||null,x.dataAbertura||null,x.dataEncerramentoProposta||x.dataFimRecebimentoPropostas||null,Number(x.valorTotalEstimado??x.valorEstimado??0)||null,'encontrado').run();
        if(!existing){saved++;await notify(env,'new_tender','Novo edital no PNCP',title||org.razaoSocial||'Nova oportunidade',localId,`pncp:${id}`)}
      }
      if(rows.length<50)break;
    }
    await env.DB.prepare('INSERT INTO app_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('last_sync',now.toISOString()).run();
    await reminders(env,now);
    await env.DB.prepare('INSERT INTO app_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('last_sync_count',String(saved)).run();
  }catch(error){
    await env.DB.prepare('INSERT INTO app_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('last_sync_error',String(error?.message||error).slice(0,350)).run();
  }
}

async function notify(env,kind,title,message,tenderId,key){
  const pref=await env.DB.prepare('SELECT enabled FROM notification_preferences WHERE key=?').bind(kind).first();
  if(pref&&pref.enabled===0)return;
  await env.DB.prepare('INSERT OR IGNORE INTO notifications(id,kind,title,message,tender_id,scheduled_key) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),kind,title,message,tenderId,key).run();
}

async function reminders(env,now){
  const prefs=await env.DB.prepare('SELECT enabled FROM notification_preferences WHERE key=?').bind('deadline').first();
  if(prefs&&prefs.enabled===0)return;
  const {results}=await env.DB.prepare(`SELECT id,title,object,proposal_deadline FROM tenders WHERE proposal_deadline IS NOT NULL AND status NOT IN ('concluida','descartada','cancelada','vencida','nao_classificada')`).all();
  const offsets=[['7d',7*86400000],['4d',4*86400000],['2d',2*86400000],['8h',8*3600000]];
  for(const t of results){
    const deadline=new Date(t.proposal_deadline).getTime();if(!Number.isFinite(deadline))continue;
    for(const [label,offset] of offsets){
      const target=deadline-offset;
      if(now.getTime()>=target&&now.getTime()<target+3*3600000){
        await notify(env,'deadline',`Prazo em ${label}`,`${t.title||t.object||'Licitação'} · prazo ${new Date(deadline).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'})}`,t.id,`deadline:${t.id}:${label}`);
      }
    }
  }
}
